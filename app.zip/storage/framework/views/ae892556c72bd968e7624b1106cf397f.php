<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\digiedu\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>